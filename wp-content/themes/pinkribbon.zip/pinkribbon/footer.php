
	<footer>
		<p>(Footer under construction)</p>

	</footer>
<?php wp_footer(); ?>
	</body>
</html>
